import asyncio
import sys
import inspect
import functools
import os
import threading
from typing import Set, Callable, Tuple

# Environment gate: completely inert if ASYNC_WARNING_DEV is not set
_ENABLED_BY_ENV = os.environ.get('ASYNC_WARNING_DEV') == '1'

# Global state (only initialized if environment is set)
_monitored_modules: Set[str] = set()
_original_functions: dict = {}
_warned_sites: Set[Tuple[str, int, str]] = set()
_ignored_functions: Set[str] = set()
_lock = threading.Lock()


class _AsyncWarningManager:
    """Internal manager for async warning detection."""
    
    def __init__(self):
        self.enabled = False
        self.monitored_modules: Set[str] = set()
        self.original_functions: dict = {}
        self.warned_sites: Set[Tuple[str, int, str]] = set()
        self.ignored_functions: Set[str] = set()
    
    def enable(self, module_name: str = None, auto_patch: bool = True) -> None:
        """
        Enable async warning for a module.
        
        Args:
            module_name: Module to monitor. If None, auto-detects caller's module.
            auto_patch: If True, automatically patch all sync functions in the module.
        """
        if not _ENABLED_BY_ENV:
            return
        
        if module_name is None:
            frame = inspect.currentframe()
            try:
                caller_frame = frame.f_back
                module_name = caller_frame.f_globals.get('__name__', '__main__')
            finally:
                del frame
        
        with _lock:
            if module_name in self.monitored_modules:
                return
            
            self.monitored_modules.add(module_name)
            self.enabled = True
            
            if auto_patch:
                self._patch_module(module_name)
    
    def disable(self, module_name: str = None) -> None:
        """
        Disable async warning for a module and restore original functions.
        
        Args:
            module_name: Module to disable. If None, auto-detects caller's module.
        """
        if not _ENABLED_BY_ENV:
            return
        
        if module_name is None:
            frame = inspect.currentframe()
            try:
                caller_frame = frame.f_back
                module_name = caller_frame.f_globals.get('__name__')
            finally:
                del frame
        
        if not module_name:
            return
        
        with _lock:
            if module_name not in self.monitored_modules:
                return
            
            self.monitored_modules.discard(module_name)
            self._unpatch_module(module_name)
    
    def _patch_module(self, module_name: str) -> None:
        """Patch all sync functions in a module."""
        try:
            module = sys.modules.get(module_name)
            if not module:
                return
            
            for name in dir(module):
                if name.startswith('_'):
                    continue
                
                try:
                    obj = getattr(module, name)
                except (AttributeError, TypeError):
                    continue
                
                if callable(obj) and not asyncio.iscoroutinefunction(obj):
                    if not inspect.isclass(obj):
                        self._patch_function(module, name, obj)
                    else:
                        self._patch_class(obj, module_name)
        
        except Exception:
            pass
    
    def _unpatch_module(self, module_name: str) -> None:
        """Restore original functions in a module."""
        try:
            module = sys.modules.get(module_name)
            if not module:
                return
            
            for name in list(dir(module)):
                key = f"{module_name}.{name}"
                if key in self.original_functions:
                    try:
                        setattr(module, name, self.original_functions[key])
                        del self.original_functions[key]
                    except (AttributeError, TypeError):
                        continue
        
        except Exception:
            pass
    
    def _patch_function(self, module, name: str, func: Callable) -> None:
        """Wrap a sync function to detect blocking calls from async context."""
        try:
            # Avoid double-patching
            if hasattr(func, '_async_warning_wrapped'):
                return
            
            key = f"{module.__name__}.{name}"
            self.original_functions[key] = func
            
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                self._check_blocking_call(name)
                return func(*args, **kwargs)
            
            wrapper._async_warning_wrapped = True
            setattr(module, name, wrapper)
        
        except Exception:
            pass
    
    def _patch_class(self, cls, module_name: str) -> None:
        """Patch all methods in a class."""
        try:
            for name in dir(cls):
                if name.startswith('_'):
                    continue
                
                try:
                    attr = getattr(cls, name)
                except (AttributeError, TypeError):
                    continue
                
                if callable(attr) and not asyncio.iscoroutinefunction(attr) and not isinstance(attr, type):
                    if hasattr(attr, '_async_warning_wrapped'):
                        continue
                    
                    original_method = attr
                    
                    def make_wrapper(original, class_name, method_name):
                        @functools.wraps(original)
                        def wrapper(*args, **kwargs):
                            self._check_blocking_call(f"{class_name}.{method_name}")
                            return original(*args, **kwargs)
                        
                        wrapper._async_warning_wrapped = True
                        return wrapper
                    
                    setattr(cls, name, make_wrapper(original_method, cls.__name__, name))
        
        except Exception:
            pass
    
    def _check_blocking_call(self, func_name: str) -> None:
        """
        Check if we're in async context and warn if blocking.
        
        This is called on every patched function invocation.
        Early exit if no running loop (sync context).
        """
        # Check if this function is ignored
        with _lock:
            if func_name in self.ignored_functions:
                return
        
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            # No running loop = sync context, all good
            return
        
        # We're in async context and made a blocking call
        frame = inspect.currentframe()
        try:
            # Skip: _check_blocking_call -> wrapper -> actual call site
            try:
                caller_frame = frame.f_back
                if caller_frame:
                    caller_frame = caller_frame.f_back
                if caller_frame:
                    caller_frame = caller_frame.f_back
            except AttributeError:
                # Call stack shallower than expected
                return
            
            if not caller_frame:
                return
            
            filename = caller_frame.f_code.co_filename
            lineno = caller_frame.f_lineno
            caller_name = caller_frame.f_code.co_name
            
            # Deduplicate by (file, line, function)
            call_site = (filename, lineno, func_name)
            
            with _lock:
                if call_site in self.warned_sites:
                    return
                
                self.warned_sites.add(call_site)
            
            # Extract just the filename for readability
            try:
                short_filename = filename.split('/')[-1]
            except Exception:
                short_filename = filename
            
            warning_msg = (
                f"ASYNC_WARNING: Blocking call {func_name}() in async context\n"
                f"  Called from: {caller_name}()\n"
                f"  Location: {short_filename}:{lineno}\n"
            )
            print(warning_msg, file=sys.stderr, end='')
        
        finally:
            del frame


# Global instance
_manager = None


def _get_manager() -> _AsyncWarningManager:
    """Get or create global manager instance."""
    global _manager
    if _manager is None:
        _manager = _AsyncWarningManager()
    return _manager


def enable(module_name: str = None, auto_patch: bool = True) -> None:
    """
    Enable async warning system for a module.
    
    This patches all sync functions in the target module to detect blocking
    calls made from async context. No decorators needed.
    
    Args:
        module_name: Module to monitor. If None, auto-detects caller's module.
        auto_patch: If True, automatically patch sync functions (default: True).
    
    Example:
        import os
        os.environ['ASYNC_WARNING_DEV'] = '1'
        
        import async_warning
        async_warning.enable()
        
        def blocking_op():
            return 42
        
        async def handler():
            blocking_op()  # Warning printed to stderr
    """
    if not _ENABLED_BY_ENV:
        return
    
    manager = _get_manager()
    manager.enable(module_name, auto_patch)


def disable(module_name: str = None) -> None:
    """
    Disable async warning and restore original functions for a module.
    
    Args:
        module_name: Module to disable. If None, auto-detects caller's module.
    """
    if not _ENABLED_BY_ENV:
        return
    
    manager = _get_manager()
    manager.disable(module_name)


def is_in_async_context() -> bool:
    """
    Check if currently running in an asyncio event loop context.
    
    Returns:
        True if running inside an async context, False otherwise.
    """
    try:
        asyncio.get_running_loop()
        return True
    except RuntimeError:
        return False


def manual_check(func_name: str = None) -> None:
    """
    Manually trigger a blocking call check at the current location.
    
    Use this to monitor specific blocking calls without auto-patching.
    
    Args:
        func_name: Name of the blocking function. If None, uses caller's function name.
    
    Example:
        async def handler():
            async_warning.manual_check("my_blocking_call")
            some_sync_function()
    """
    if not _ENABLED_BY_ENV:
        return
    
    if func_name is None:
        frame = inspect.currentframe()
        try:
            func_name = frame.f_back.f_code.co_name
        finally:
            del frame
    
    manager = _get_manager()
    manager._check_blocking_call(func_name)


def ignore(func: Callable = None, *, func_name: str = None) -> Callable:
    """
    Decorator to suppress async warnings for a specific function.
    
    Can be used as @ignore or @ignore(func_name="custom_name").
    
    Args:
        func: Function to decorate (when used as @ignore).
        func_name: Custom name to ignore (when used as @ignore(func_name="...")).
    
    Example:
        @async_warning.ignore
        def intentionally_blocking():
            time.sleep(1)
        
        @async_warning.ignore(func_name="Database.connect")
        async def handler():
            db.connect()  # No warning
    """
    if not _ENABLED_BY_ENV:
        # Return pass-through decorator
        if func is not None:
            return func
        return lambda f: f
    
    manager = _get_manager()
    
    # @ignore(func_name="...")
    if func is None:
        if func_name:
            with _lock:
                manager.ignored_functions.add(func_name)
        
        def decorator(f):
            return f
        return decorator
    
    # @ignore
    name = func.__name__
    with _lock:
        manager.ignored_functions.add(name)
    
    return func


__all__ = [
    'enable',
    'disable',
    'is_in_async_context',
    'manual_check',
    'ignore',
]