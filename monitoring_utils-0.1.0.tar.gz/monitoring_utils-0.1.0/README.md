# monitorning_utils
This is a python package to be used across multiple python repositories for reusability and maintainability of the code.

### Setting Up
To set up your Python environment, you will need to install setuptools, wheel, and twine.

You can install these tools using pip:

```bash
pip install setuptools wheel twine
```


### Configure Setup.py
It contains information about the package such as its name, version, and dependencies. 

```python
from setuptools import setup, find_packages

setup(
    name="monitoring_utils",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
)
```

Whenever we change the code for publishing we need to update the version number here.


## Build the package
To build the package, you will need to use the setuptools and wheel libraries. These libraries allow you to generate distribution archives that can be installed using pip.

You can build the package by running the following command:

```bash
python setup.py sdist bdist_wheel
```

## Local Testing
To locally test this package run the following command to install this in your local environment
```bash
pip install path/to/dist/monitoring_utils-LATEST_VERSION-py3-none-any.whl
```

## Usage
To use this package <br>
Update <em>requirements.txt</em> file in your project with:
```
https://d2bhph719sjxlc.cloudfront.net/python-packages/simple/monitoring_utils/monitoring_utils-[VERSION]-py3-none-any.whl
```

### Configuration

Before using the monitoring utilities, you need to set up the following environment variable:

```bash
export MONITORING_ENDPOINT="http://localhost:8429"
```

This environment variable specifies the endpoint where metrics will be sent.

Configure the monitoring client with the following parameters:

```python
from monitoring_utils import configure

configure(
    batch_interval=10,           
    batch_size=5,               
    default_labels={"app": "sample_app"},
    max_retries=5,               
    retry_backoff=2.0            
)
```

**Configuration Parameters:**
- `batch_interval` (int): Time in seconds between batch sends
- `batch_size` (int): Maximum metrics to accumulate in a batch
- `default_labels` (dict): Default labels applied to all metrics
- `max_retries` (int): Maximum retry attempts for failed requests
- `retry_backoff` (float): Exponential backoff multiplier for retries

---

## Sync Usage

For synchronous applications (Flask, Django, scripts).

### Basic Example

```python
from monitoring_utils import counter, gauge, histogram, shutdown

# Metrics
counter("requests_total", labels={"method": "GET"})      # Auto-increments
gauge("memory_bytes", 1024000)                           # Absolute value
histogram("response_time_seconds", 0.245)                # Distribution

# Manual flush (optional)
from monitoring_utils import flush
flush()
```

---

## Async Usage

For async applications (FastAPI, aiohttp, asyncio).

### Basic Example

```python
from monitoring_utils.aio import counter, gauge, histogram, lifespan

async def main():
    async with lifespan():  # Auto-cleanup on exit
        await counter("requests_total", labels={"method": "POST"})
        await gauge("active_connections", 42)
        await histogram("query_duration_seconds", 0.123)

# Or with manual shutdown
from monitoring_utils.aio import shutdown

async def main():
    await counter("requests_total")
    await shutdown()  # Must call this!
```

## Metric Types

| Type | Behavior | Example |
|------|----------|---------|
| **counter** | Monotonically increasing, tracks state | `counter("requests_total", 1)` |
| **gauge** | Can go up/down, absolute value | `gauge("cpu_percent", 45.2)` |
| **histogram** | Measures distributions | `histogram("latency_seconds", 0.12)` |

### Counter State Tracking

```python
# Sync
counter("requests_total", labels={"method": "GET"})  # Sends: 1
counter("requests_total", labels={"method": "GET"})  # Sends: 2
counter("requests_total", labels={"method": "GET"})  # Sends: 3

# Async
await counter("requests_total", labels={"method": "POST"})  # Sends: 1
await counter("requests_total", labels={"method": "POST"})  # Sends: 2
```

### Gauge Absolute Values

```python
# Sync
gauge("memory_bytes", 1024000)  # Sends: 1024000
gauge("memory_bytes", 2048000)  # Sends: 2048000 (not cumulative)

# Async
await gauge("temperature_celsius", 23.5)  # Sends: 23.5
await gauge("temperature_celsius", 24.1)  # Sends: 24.1
```

---

## Advanced Options

### Immediate Send (Skip Batching)

```python
# Sync
counter("critical_error", batch=False)  # Sends immediately

# Async
await counter("critical_error", batch=False)
```

### Per-Metric Retry Configuration

```python
# Sync
counter("important_metric", max_retries=5, retry_backoff=2.0)

# Async
await counter("important_metric", max_retries=5, retry_backoff=2.0)
```

## To deploy
Run:
```
./build_production.sh 
```

After this there will be change in file:
```
index.html
```
Commit this changes

## For testing:
Run:
```
python -m unittest discover -s monitoring_utils -p "test_*.py"
```


# async_warning

Development tool to detect blocking calls in async code. **Only active when `ASYNC_WARNING_DEV=1` is set.**

### Setup

```bash
export ASYNC_WARNING_DEV=1  # Enable warnings (dev/staging only)
```

### Auto-Detection

```python
import async_warning
async_warning.enable()  # Auto-patches all sync functions

def blocking_call():
    return "data"

async def handler():
    blocking_call()  # ⚠️ Warning printed to stderr
```

**Output:**
```
ASYNC_WARNING: Blocking call blocking_call() in async context
  Called from: handler()
  Location: app.py:42
```

### Manual Check

```python
async def handler():
    async_warning.manual_check("database_query")
    db.execute("SELECT ...")  # ⚠️ Warning if blocking
```

### Suppress Warnings

```python
@async_warning.ignore
def intentionally_blocking():
    time.sleep(1)

# Or by name
async_warning.ignore(func_name="Database.connect")
```

### Context Check

```python
if async_warning.is_in_async_context():
    await async_operation()
else:
    sync_operation()
```

### Disable

```python
async_warning.disable()  # Restores original functions
```
