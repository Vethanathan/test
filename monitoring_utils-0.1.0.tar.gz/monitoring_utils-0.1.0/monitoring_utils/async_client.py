import asyncio
import time
import logging
from typing import Dict, Optional

from .models import Metric, MetricType, AsyncCounterRegistry
from .async_transport import AsyncMetricsTransport
from .async_worker import AsyncMetricsWorker
from .exceptions import ConfigurationError

logger = logging.getLogger(__name__)


class AsyncMetricsClient:
    """Async client for sending metrics to Monitoring stack.
    
    This is a non-blocking client that uses asyncio for all I/O operations.
    Supports batching mode where metrics are queued and sent efficiently.
    
    Attributes:
        default_labels: Labels added to all metrics
        transport: Async HTTP transport for sending metrics
        worker: Background async worker for batching
    """
    
    def __init__(
        self,
        endpoint: str,
        username: Optional[str] = None,
        password: Optional[str] = None,
        default_labels: Optional[Dict[str, str]] = None,
        batch_size: int = 100,
        batch_interval: int = 1,
        max_retries: int = 3,
        timeout: int = 3,
        retry_backoff: float = 1.0,
    ):
        """Initialize the async metrics client.
        
        Args:
            endpoint: Monitoring stack endpoint URL (e.g., 'http://vmagent:8429')
            username: Optional HTTP basic auth username
            password: Optional HTTP basic auth password
            default_labels: Labels to add to all metrics (e.g., {"service": "api"})
            batch_size: Max metrics per batch (default: 100)
            batch_interval: Seconds between flushes (default: 1)
            max_retries: Max retry attempts on failure (default: 3)
            timeout: HTTP timeout in seconds (default: 3)
            retry_backoff: Backoff multiplier between retries (default: 1.0)
        
        Raises:
            ConfigurationError: If endpoint is invalid
        """
        if not endpoint:
            raise ConfigurationError("Endpoint cannot be empty")
        
        self.default_labels = default_labels or {}
        self.counter_registry = AsyncCounterRegistry()
        
        # Setup async HTTP transport
        auth = (username, password) if username and password else None
        self.transport = AsyncMetricsTransport(
            endpoint=endpoint,
            auth=auth,
            timeout=timeout,
            max_retries=max_retries,
            retry_backoff=retry_backoff,
        )
        
        # Setup background worker for batching
        self.worker = AsyncMetricsWorker(
            transport=self.transport,
            flush_interval=batch_interval,
            max_batch=batch_size,
        )
        self._worker_task: Optional[asyncio.Task] = None
        self._started = False
        
        logger.info(
            f"AsyncMetricsClient initialized: endpoint={endpoint}, "
            f"batch_size={batch_size}, batch_interval={batch_interval}s"
        )
    
    async def start(self) -> None:
        """Start the background worker task."""
        if not self._started:
            self._worker_task = asyncio.create_task(self.worker.run())
            self._started = True
            
            # Verify vmagent is reachable
            try:
                test_metric = Metric(
                    name="_monitoring_utils_health_check",
                    value=1,
                    labels={"status": "ok"},
                    timestamp=int(time.time()),
                )
                await self.transport.send(test_metric.to_prometheus() + "\n")
                logger.info("Successfully connected to vmagent")
            except Exception as e:
                logger.error(f"Failed to reach vmagent at {self.transport.endpoint}: {e}")
                raise ConfigurationError(f"vmagent unreachable: {e}")
            
            logger.debug("AsyncMetricsWorker started")
    
    async def emit(
        self,
        name: str,
        value: float,
        labels: Optional[Dict[str, str]] = None,
        metric_type: Optional[MetricType] = None,
        batch: bool = True,
        max_retries: Optional[int] = None,
        retry_backoff: Optional[float] = None,
    ) -> None:
        """Emit a metric asynchronously.
        
        Args:
            name: Metric name (e.g., 'http_requests_total')
            value: Metric value
            labels: Optional labels for this metric
            metric_type: Type of metric (counter, gauge, histogram, summary)
            batch: If True, queue for batching; if False, send immediately
            max_retries: Override default max_retries for this metric
            retry_backoff: Override default retry_backoff for this metric
        """
        # Ensure worker is started
        if not self._started:
            await self.start()
        
        # Merge default labels with metric-specific labels
        merged_labels = {**self.default_labels, **(labels or {})}
        
        # Create metric with current timestamp in SECONDS (Prometheus standard)
        metric = Metric(
            name=name,
            value=value,
            labels=merged_labels,
            timestamp=int(time.time()),  # SECONDS, not milliseconds
            metric_type=metric_type.value if metric_type else None,
            max_retries=max_retries,
            retry_backoff=retry_backoff,
        )
        
        if batch:
            # Queue for batching (non-blocking)
            await self.worker.submit(metric)
        else:
            # Send immediately (async but waits for completion)
            payload = metric.to_prometheus() + "\n"
            try:
                await self.transport.send(payload, max_retries, retry_backoff)
            except Exception as e:
                logger.error(f"Failed to send immediate metric '{name}': {e}")
    
    async def counter(
        self,
        name: str,
        value: float = 1.0,
        labels: Optional[Dict[str, str]] = None,
        batch: bool = True,
    ) -> None:
        """Emit a counter metric (monotonically increasing).
        
        Tracks state automatically. Each call increments the counter by 'value'.
        
        Args:
            name: Metric name (should end with _total by convention)
            value: Value to increment by (default: 1.0)
            labels: Optional labels
            batch: Enable batching
        """
        # Increment counter state (THIS IS +=, NOT =)
        counter_value = await self.counter_registry.increment(name, value, labels)
        
        # Send the accumulated value
        await self.emit(name, counter_value, labels, MetricType.COUNTER, batch)
    
    async def gauge(
        self,
        name: str,
        value: float,
        labels: Optional[Dict[str, str]] = None,
        batch: bool = True,
    ) -> None:
        """Emit a gauge metric (can go up or down).
        
        Args:
            name: Metric name
            value: Current value (absolute, not increment)
            labels: Optional labels
            batch: Enable batching
        """
        await self.emit(name, value, labels, MetricType.GAUGE, batch)
    
    async def histogram(
        self,
        name: str,
        value: float,
        labels: Optional[Dict[str, str]] = None,
        batch: bool = True,
    ) -> None:
        """Emit a histogram metric (for measuring distributions).
        
        Args:
            name: Metric name
            value: Observed value
            labels: Optional labels
            batch: Enable batching
        """
        await self.emit(name, value, labels, MetricType.HISTOGRAM, batch)
    
    async def flush(self, timeout: float = 1.0) -> None:
        """Flush all queued metrics immediately.
        
        Args:
            timeout: Seconds to wait for flush to complete
        """
        await self.worker.flush_now()
        await asyncio.sleep(timeout)  # Give worker time to process flush
    
    async def shutdown(self, timeout: int = 10) -> None:
        """Gracefully shutdown the client and flush remaining metrics.
        
        Args:
            timeout: Max seconds to wait for shutdown
        """
        if not self._started:
            return
            
        logger.info("Shutting down AsyncMetricsClient...")
        
        if self._worker_task:
            await self.worker.stop()
            try:
                await asyncio.wait_for(self._worker_task, timeout=timeout)
            except asyncio.TimeoutError:
                logger.warning(f"Worker task did not complete within {timeout}s")
                self._worker_task.cancel()
                try:
                    await self._worker_task
                except asyncio.CancelledError:
                    pass
        
        await self.transport.close()
        self._started = False
        logger.info("AsyncMetricsClient shutdown complete")
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.start()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - ensures shutdown."""
        await self.shutdown()
