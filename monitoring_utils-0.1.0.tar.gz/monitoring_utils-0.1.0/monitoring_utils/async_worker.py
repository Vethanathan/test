import asyncio
import time
import logging
from typing import List

from .models import Metric
from .async_transport import AsyncMetricsTransport

logger = logging.getLogger(__name__)


class AsyncMetricsWorker:
    """Async background task that batches metrics and flushes them periodically.
    
    Metrics are collected in an asyncio queue and flushed when:
    - Batch size reaches max_batch (immediate flush)
    - flush_interval seconds have elapsed since last flush
    - Manual flush is requested via flush_now()
    - Worker is stopped (final flush)
    
    Attributes:
        transport: AsyncMetricsTransport instance for sending metrics
        flush_interval: Seconds between automatic flushes
        max_batch: Maximum metrics per batch before forcing flush
        queue: Async queue for collecting metrics
    """
    
    def __init__(
        self,
        transport: AsyncMetricsTransport,
        flush_interval: int = 1,
        max_batch: int = 100,
    ):
        """Initialize the async metrics worker.
        
        Args:
            transport: AsyncMetricsTransport instance for sending metrics
            flush_interval: Seconds between automatic flushes (default: 1)
            max_batch: Maximum metrics per batch (default: 100)
        """
        self.transport = transport
        self.flush_interval = flush_interval
        self.max_batch = max_batch
        self.queue: asyncio.Queue[Metric] = asyncio.Queue()
        self._stop_event = asyncio.Event()
        self._flush_event = asyncio.Event()
        
        logger.debug(
            f"AsyncMetricsWorker initialized: "
            f"flush_interval={flush_interval}s, max_batch={max_batch}"
        )
    
    async def run(self) -> None:
        """Main worker loop - collects and flushes metrics.
        
        This runs as an asyncio task and continuously:
        1. Collects metrics from the queue
        2. Flushes immediately when batch size is reached
        3. Flushes when time interval is reached
        4. Handles manual flush requests
        5. Performs final flush on shutdown
        """
        buffer: List[Metric] = []
        last_flush = time.time()
        
        while not self._stop_event.is_set():
            try:
                # Wait for metrics with timeout to allow checking stop/flush events
                metric = await asyncio.wait_for(
                    self.queue.get(),
                    timeout=0.1  # Shorter timeout for faster response
                )
                buffer.append(metric)
                
                # IMMEDIATE FLUSH when batch is full
                if len(buffer) >= self.max_batch:
                    await self._flush_batch(buffer)
                    buffer.clear()
                    last_flush = time.time()
                    continue
                    
            except asyncio.TimeoutError:
                pass  # No metrics available, continue to check flush conditions
            
            # Check if manual flush was requested (atomic operation)
            if self._flush_event.is_set():
                self._flush_event.clear()  # Clear immediately to prevent race
                if buffer:
                    await self._flush_batch(buffer)
                    buffer.clear()
                    last_flush = time.time()
                continue
            
            # Check time-based auto-flush
            now = time.time()
            if buffer and (now - last_flush) >= self.flush_interval:
                await self._flush_batch(buffer)
                buffer.clear()
                last_flush = now
        
        # Final flush on shutdown
        if buffer:
            logger.info(f"Final flush: {len(buffer)} metrics")
            await self._flush_batch(buffer)
    
    async def _flush_batch(self, metrics: List[Metric]) -> None:
        """Flush a batch of metrics to Monitoring stack.
        
        Args:
            metrics: List of Metric objects to send
        """
        if not metrics:
            return
        
        # Convert all metrics to Prometheus format
        payload = "\n".join(m.to_prometheus() for m in metrics) + "\n"
        
        # Use retry settings from first metric (they should all be the same in a batch)
        max_retries = metrics[0].max_retries
        retry_backoff = metrics[0].retry_backoff
        
        try:
            await self.transport.send(payload, max_retries, retry_backoff)
            logger.debug(f"Flushed batch of {len(metrics)} metrics")
        except Exception as e:
            # Never crash the worker - log error and continue
            logger.error(
                f"Failed to flush batch of {len(metrics)} metrics: {e}",
                exc_info=True
            )
    
    async def submit(self, metric: Metric) -> None:
        """Submit a metric to be batched and sent.
        
        This is async-safe and can be called from multiple coroutines.
        
        Args:
            metric: Metric object to queue for sending
        """
        await self.queue.put(metric)
    
    async def flush_now(self) -> None:
        """Request immediate flush of queued metrics.
        
        This signals the worker to flush on its next iteration.
        Non-blocking - returns immediately.
        """
        self._flush_event.set()
    
    async def stop(self) -> None:
        """Stop the worker and flush remaining metrics."""
        logger.debug("Stopping AsyncMetricsWorker...")
        self._stop_event.set()
        logger.debug("AsyncMetricsWorker stop signal sent")
