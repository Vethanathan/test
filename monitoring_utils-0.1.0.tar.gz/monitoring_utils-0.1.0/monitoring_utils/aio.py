
import os
import logging
import asyncio
from typing import Dict, Optional
from contextlib import asynccontextmanager

from .async_client import AsyncMetricsClient
from .exceptions import ConfigurationError

__all__ = ["metric", "counter", "gauge", "histogram", "flush", "shutdown", "configure", "lifespan"]

# Setup logging
logger = logging.getLogger(__name__)

# Global singleton
_client: Optional[AsyncMetricsClient] = None
_config = {
    "batch_size": 100,
    "batch_interval": 1,  # Reduced from 5 to 1 second
    "max_retries": 3,
    "timeout": 3,
    "retry_backoff": 1.0,
}


def configure(
    batch_size: Optional[int] = None,
    batch_interval: Optional[int] = None,
    max_retries: Optional[int] = None,
    timeout: Optional[int] = None,
    retry_backoff: Optional[float] = None,
) -> None:
    """
    Configure global async metrics behavior (optional).
    
    Args:
        batch_size: Metrics per batch (default: 100)
        batch_interval: Seconds between flushes (default: 1)
        max_retries: Retry attempts on failure (default: 3)
        timeout: HTTP timeout in seconds (default: 3)
        retry_backoff: Backoff multiplier between retries (default: 1.0)
    """
    global _config, _client
    
    if batch_size is not None:
        _config["batch_size"] = batch_size
    if batch_interval is not None:
        _config["batch_interval"] = batch_interval
    if max_retries is not None:
        _config["max_retries"] = max_retries
    if timeout is not None:
        _config["timeout"] = timeout
    if retry_backoff is not None:
        _config["retry_backoff"] = retry_backoff
    
    # Warn if client already initialized
    if _client is not None:
        logger.warning(
            "Client already initialized. Configuration changes will take effect "
            "after calling shutdown() and creating a new client."
        )


async def _get_client() -> AsyncMetricsClient:
    """Lazy-initialize the global async metrics client."""
    global _client
    
    if _client is None:
        # Get endpoint from environment
        endpoint = os.getenv("MONITORING_ENDPOINT")
        if not endpoint:
            raise ConfigurationError(
                "MONITORING_ENDPOINT environment variable not set!"
            )
        
        # Optional credentials
        username = os.getenv("MONITORING_USERNAME")
        password = os.getenv("MONITORING_PASSWORD")
        
        # Optional default labels from environment
        default_labels = {}
        if service := os.getenv("SERVICE_NAME"):
            default_labels["service"] = service
        if env := os.getenv("ENV"):
            default_labels["env"] = env
        
        # Create client instance
        _client = AsyncMetricsClient(
            endpoint=endpoint,
            username=username,
            password=password,
            default_labels=default_labels,
            batch_size=_config["batch_size"],
            batch_interval=_config["batch_interval"],
            max_retries=_config["max_retries"],
            timeout=_config["timeout"],
            retry_backoff=_config["retry_backoff"],
        )
        
        # Start the worker
        await _client.start()
    
    return _client


@asynccontextmanager
async def lifespan():
    """
    Context manager for managing async metrics lifecycle.
    
    Ensures proper cleanup and flushing on exit. This is the RECOMMENDED way
    to use async metrics.
    
    Usage:
        async with lifespan():
            await counter("requests_total")
            await gauge("memory_bytes", 1024000)
            # Auto-flushes and shuts down on exit
    """
    try:
        yield
    finally:
        await shutdown()


async def metric(
    name: str,
    value: float,
    labels: Optional[Dict[str, str]] = None,
    *,
    batch: bool = True,
    max_retries: Optional[int] = None,
    retry_backoff: Optional[float] = None,
) -> None:
    """
    Send a metric to Monitoring stack (async).
    
    Args:
        name: Metric name (e.g., 'http_requests_total')
        value: Metric value
        labels: Optional dict of label key-value pairs
        batch: Enable batching (default: True)
        max_retries: Override retry attempts for this metric
        retry_backoff: Override retry backoff for this metric
    """
    client = await _get_client()
    
    try:
        await client.emit(
            name=name,
            value=value,
            labels=labels,
            batch=batch,
            max_retries=max_retries,
            retry_backoff=retry_backoff,
        )
    except Exception as e:
        logger.error(f"Failed to send metric '{name}': {e}")


async def counter(
    name: str,
    value: float = 1.0,
    labels: Optional[Dict[str, str]] = None,
    *,
    batch: bool = True,
) -> None:
    """
    Send a counter metric (monotonically increasing) with state tracking.
    
    Counter automatically tracks state - each call increments by 'value'.
    
    Args:
        name: Metric name (should end with _total by convention)
        value: Amount to increment (default: 1.0)
        labels: Optional dict of label key-value pairs
        batch: Enable batching (default: True)
    
    Example:
        await counter("requests_total", labels={"method": "GET"})  # +1
        await counter("requests_total", 5, labels={"method": "POST"})  # +5
    """
    client = await _get_client()
    
    try:
        await client.counter(name=name, value=value, labels=labels, batch=batch)
    except Exception as e:
        logger.error(f"Failed to send counter '{name}': {e}")


async def gauge(
    name: str,
    value: float,
    labels: Optional[Dict[str, str]] = None,
    *,
    batch: bool = True,
) -> None:
    """
    Send a gauge metric (can go up or down).
    
    Gauge represents a value that can increase or decrease (e.g., memory usage).
    
    Args:
        name: Metric name
        value: Current value (absolute, not delta)
        labels: Optional dict of label key-value pairs
        batch: Enable batching (default: True)
    
    Example:
        await gauge("memory_bytes", 1024000)
        await gauge("cpu_percent", 45.2, labels={"core": "0"})
    """
    client = await _get_client()
    
    try:
        await client.gauge(name=name, value=value, labels=labels, batch=batch)
    except Exception as e:
        logger.error(f"Failed to send gauge '{name}': {e}")


async def histogram(
    name: str,
    value: float,
    labels: Optional[Dict[str, str]] = None,
    *,
    batch: bool = True,
) -> None:
    """
    Send a histogram metric (for measuring distributions).
    
    Histogram tracks the distribution of values (e.g., request latencies).
    
    Args:
        name: Metric name
        value: Observed value
        labels: Optional dict of label key-value pairs
        batch: Enable batching (default: True)
    
    Example:
        await histogram("request_duration_seconds", 0.123)
        await histogram("response_size_bytes", 4096, labels={"endpoint": "/api"})
    """
    client = await _get_client()
    
    try:
        await client.histogram(name=name, value=value, labels=labels, batch=batch)
    except Exception as e:
        logger.error(f"Failed to send histogram '{name}': {e}")


async def flush(timeout: float = 1.0) -> None:
    """
    Flush all queued metrics immediately.
    
    Args:
        timeout: Seconds to wait for flush to complete (default: 1.0)
    """
    global _client
    if _client:
        await _client.flush(timeout=timeout)


async def shutdown(timeout: int = 10) -> None:
    """
    Gracefully shutdown metrics client and flush remaining metrics.
    
    IMPORTANT: You MUST call this when using async metrics without the
    lifespan() context manager. Otherwise, metrics may be lost.
    
    Args:
        timeout: Max seconds to wait for shutdown (default: 10)
    """
    global _client
    if _client:
        await _client.shutdown(timeout=timeout)
        _client = None
