"""Background worker thread for batching and flushing metrics."""

import queue
import threading
import time
import logging
from typing import List

from .models import Metric
from .transport import MetricsTransport

logger = logging.getLogger(__name__)


class MetricsWorker(threading.Thread):
    """Background thread that batches metrics and flushes them periodically.
    
    Metrics are collected in a queue and flushed when:
    - Batch size reaches max_batch
    - flush_interval seconds have elapsed since last flush
    - Manual flush is requested via flush_now()
    - Worker is stopped (final flush)
    
    Attributes:
        transport: MetricsTransport instance for sending metrics
        flush_interval: Seconds between automatic flushes
        max_batch: Maximum metrics per batch before forcing flush
        queue: Thread-safe queue for collecting metrics
    """
    
    def __init__(
        self,
        transport: MetricsTransport,
        flush_interval: int = 1,
        max_batch: int = 100,
    ):
        """Initialize the metrics worker.
        
        Args:
            transport: MetricsTransport instance for sending metrics
            flush_interval: Seconds between automatic flushes (default: 1)
            max_batch: Maximum metrics per batch (default: 100)
        """
        super().__init__(daemon=True, name="MetricsWorker")
        self.transport = transport
        self.flush_interval = flush_interval
        self.max_batch = max_batch
        self.queue: queue.Queue[Metric] = queue.Queue()
        self._stop_event = threading.Event()
        self._flush_event = threading.Event()
        
        logger.debug(
            f"MetricsWorker initialized: "
            f"flush_interval={flush_interval}s, max_batch={max_batch}"
        )
    
    def run(self) -> None:
        """Main worker loop - collects and flushes metrics.
        
        This runs in a background thread and continuously:
        1. Collects metrics from the queue
        2. Flushes immediately when batch size is reached
        3. Flushes when time interval is reached
        4. Handles manual flush requests
        5. Performs final flush on shutdown
        """
        buffer: List[Metric] = []
        last_flush = time.time()
        
        while not self._stop_event.is_set():
            try:
                # Wait for metrics with timeout to allow checking stop/flush events
                metric = self.queue.get(timeout=0.1)
                buffer.append(metric)
                
                # IMMEDIATE FLUSH when batch is full
                if len(buffer) >= self.max_batch:
                    self._flush_batch(buffer)
                    buffer.clear()
                    last_flush = time.time()
                    continue
                    
            except queue.Empty:
                pass  # No metrics available, continue to check flush conditions
            
            # Check if manual flush was requested
            if self._flush_event.is_set():
                self._flush_event.clear()
                if buffer:
                    self._flush_batch(buffer)
                    buffer.clear()
                    last_flush = time.time()
                continue
            
            # Check time-based auto-flush
            now = time.time()
            if buffer and (now - last_flush) >= self.flush_interval:
                self._flush_batch(buffer)
                buffer.clear()
                last_flush = now
        
        # Final flush on shutdown
        if buffer:
            logger.info(f"Final flush: {len(buffer)} metrics")
            self._flush_batch(buffer)
    
    def _flush_batch(self, metrics: List[Metric]) -> None:
        """Flush a batch of metrics to Monitoring stack.
        
        Args:
            metrics: List of Metric objects to send
        """
        if not metrics:
            return
        
        # Convert all metrics to Prometheus format
        payload = "\n".join(m.to_prometheus() for m in metrics) + "\n"
        
        # Use retry settings from first metric (they should all be the same in a batch)
        max_retries = metrics[0].max_retries
        retry_backoff = metrics[0].retry_backoff
        
        try:
            self.transport.send(payload, max_retries, retry_backoff)
            logger.debug(f"Flushed batch of {len(metrics)} metrics")
        except Exception as e:
            # Never crash the worker thread - log error and continue
            logger.error(
                f"Failed to flush batch of {len(metrics)} metrics: {e}",
                exc_info=True
            )
    
    def submit(self, metric: Metric) -> None:
        """Submit a metric to be batched and sent.
        
        This is thread-safe and can be called from multiple threads.
        
        Args:
            metric: Metric object to queue for sending
        """
        self.queue.put(metric)
    
    def flush_now(self) -> None:
        """Request immediate flush of queued metrics.
        
        This signals the worker thread to flush on its next iteration.
        Non-blocking - returns immediately.
        """
        self._flush_event.set()
    
    def stop(self, timeout: int = 10) -> None:
        """Stop the worker thread and flush remaining metrics.
        
        Args:
            timeout: Maximum seconds to wait for clean shutdown
        """
        logger.debug("Stopping MetricsWorker...")
        self._stop_event.set()
        self.join(timeout=timeout)
        
        if self.is_alive():
            logger.warning(
                f"MetricsWorker did not stop within {timeout}s timeout"
            )
        else:
            logger.debug("MetricsWorker stopped successfully")
