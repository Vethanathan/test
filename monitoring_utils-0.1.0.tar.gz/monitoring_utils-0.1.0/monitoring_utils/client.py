"""Main client for metrics collection and sending."""

import time
import logging
from typing import Dict, Optional

from .models import Metric, MetricType, SyncCounterRegistry
from .transport import MetricsTransport
from .worker import MetricsWorker
from .exceptions import ConfigurationError

logger = logging.getLogger(__name__)


class MetricsClient:
    """Client for sending metrics to Monitoring stack.
    
    This is a low-level client used internally. Most users should use
    the high-level functions from the package root instead.
    
    The client supports batching mode where metrics are queued
    and sent in efficient batches.
    
    Attributes:
        default_labels: Labels added to all metrics
        transport: HTTP transport for sending metrics
        worker: Background worker for batching
    """
    
    def __init__(
        self,
        endpoint: str,
        username: Optional[str] = None,
        password: Optional[str] = None,
        default_labels: Optional[Dict[str, str]] = None,
        batch_size: int = 100,
        batch_interval: int = 1,
        max_retries: int = 3,
        timeout: int = 3,
        retry_backoff: float = 1.0,
    ):
        """Initialize the metrics client.
        
        Args:
            endpoint: Monitoring stack endpoint URL (e.g., 'http://vmagent:8429')
            username: Optional HTTP basic auth username
            password: Optional HTTP basic auth password
            default_labels: Labels to add to all metrics (e.g., {"service": "api"})
            batch_size: Max metrics per batch (default: 100)
            batch_interval: Seconds between flushes (default: 1)
            max_retries: Max retry attempts on failure (default: 3)
            timeout: HTTP timeout in seconds (default: 3)
            retry_backoff: Backoff multiplier between retries (default: 1.0)
        
        Raises:
            ConfigurationError: If endpoint is invalid
        """
        if not endpoint:
            raise ConfigurationError("Endpoint cannot be empty")
        
        self.default_labels = default_labels or {}
        self.counter_registry = SyncCounterRegistry()
        
        # Setup HTTP transport
        auth = (username, password) if username and password else None
        self.transport = MetricsTransport(
            endpoint=endpoint,
            auth=auth,
            timeout=timeout,
            max_retries=max_retries,
            retry_backoff=retry_backoff,
        )
        
        try:
            test_metric = Metric(
                name="_monitoring_utils_health_check",
                value=1,
                labels={"status": "ok"},
                timestamp=int(time.time()),
            )
            self.transport.send(test_metric.to_prometheus() + "\n")
            logger.info("Successfully connected to metrics endpoint")
        except Exception as e:
            logger.error(f"Failed to reach metrics endpoint at {self.transport.endpoint}: {e}")
            raise ConfigurationError(f"metrics endpoint unreachable: {e}")
        
        # Setup background worker for batching
        self.worker = MetricsWorker(
            transport=self.transport,
            flush_interval=batch_interval,
            max_batch=batch_size,
        )
        self.worker.start()
        
        logger.info(
            f"MetricsClient initialized: endpoint={endpoint}, "
            f"batch_size={batch_size}, batch_interval={batch_interval}s"
        )
    
    def emit(
        self,
        name: str,
        value: float,
        labels: Optional[Dict[str, str]] = None,
        metric_type: Optional[MetricType] = None,
        batch: bool = True,
        max_retries: Optional[int] = None,
        retry_backoff: Optional[float] = None,
    ) -> None:
        """Emit a metric.
        
        Args:
            name: Metric name (e.g., 'http_requests_total')
            value: Metric value
            labels: Optional labels for this metric
            metric_type: Type of metric (counter, gauge, histogram, summary)
            batch: If True, queue for batching; if False, send immediately
            max_retries: Override default max_retries for this metric
            retry_backoff: Override default retry_backoff for this metric
        """
        # Merge default labels with metric-specific labels
        merged_labels = {**self.default_labels, **(labels or {})}
        
        # Create metric with current timestamp in SECONDS (Prometheus standard)
        metric = Metric(
            name=name,
            value=value,
            labels=merged_labels,
            timestamp=int(time.time()),
            metric_type=metric_type.value if metric_type else None,
            max_retries=max_retries,
            retry_backoff=retry_backoff,
        )
        
        if batch:
            # Queue for batching
            self.worker.submit(metric)
        else:
            # Send immediately
            payload = metric.to_prometheus() + "\n"
            try:
                self.transport.send(payload, max_retries, retry_backoff)
            except Exception as e:
                logger.error(f"Failed to send immediate metric '{name}': {e}")
    
    def counter(
        self,
        name: str,
        value: float = 1.0,
        labels: Optional[Dict[str, str]] = None,
        batch: bool = True,
    ) -> None:
        """Emit a counter metric (monotonically increasing).
        
        Tracks state automatically. Each call increments the counter by 'value'.
        
        Args:
            name: Metric name (should end with _total by convention)
            value: Value to increment by (default: 1.0)
            labels: Optional labels
            batch: Enable batching
        """
        # Increment counter state 
        counter_value = self.counter_registry.increment(name, value, labels)
        
        # Send the accumulated value
        self.emit(name, counter_value, labels, MetricType.COUNTER, batch)
    
    def gauge(
        self,
        name: str,
        value: float,
        labels: Optional[Dict[str, str]] = None,
        batch: bool = True,
    ) -> None:
        """Emit a gauge metric (can go up or down).
        
        Args:
            name: Metric name
            value: Current value (absolute, not increment)
            labels: Optional labels
            batch: Enable batching
        """
        self.emit(name, value, labels, MetricType.GAUGE, batch)
    
    def histogram(
        self,
        name: str,
        value: float,
        labels: Optional[Dict[str, str]] = None,
        batch: bool = True,
    ) -> None:
        """Emit a histogram metric (for measuring distributions).
        
        Args:
            name: Metric name
            value: Observed value
            labels: Optional labels
            batch: Enable batching
        """
        self.emit(name, value, labels, MetricType.HISTOGRAM, batch)
    
    def flush(self, timeout: float = 1.0) -> None:
        """Flush all queued metrics immediately.
        
        Args:
            timeout: Seconds to wait for flush to complete
        """
        self.worker.flush_now()
        time.sleep(timeout) 
    
    def shutdown(self, timeout: int = 10) -> None:
        """Gracefully shutdown the client and flush remaining metrics.
        
        Args:
            timeout: Max seconds to wait for shutdown
        """
        logger.info("Shutting down MetricsClient...")
        self.worker.stop(timeout=timeout)
        self.transport.close()
        logger.info("MetricsClient shutdown complete")
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - ensures shutdown."""
        self.shutdown()
