"""Custom exceptions for monitoring_utils."""


class MetricsError(Exception):
    """Base exception for all metrics-related errors."""
    pass


class TransportError(MetricsError):
    """Error during HTTP transport to Monitoring stack."""
    pass


class ConfigurationError(MetricsError):
    """Error in metrics configuration."""
    pass


class ValidationError(MetricsError):
    """Error validating metric data."""
    pass
