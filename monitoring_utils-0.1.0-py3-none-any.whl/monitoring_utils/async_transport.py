import asyncio
import logging
from typing import Optional, Tuple

import aiohttp

from .exceptions import TransportError

logger = logging.getLogger(__name__)


class AsyncMetricsTransport:
    """Async HTTP transport for Monitoring stack.
    
    Handles:
    - Connection pooling via aiohttp
    - Automatic retries with exponential backoff
    - Request timeouts
    - HTTP basic authentication
    
    Attributes:
        endpoint: Full Monitoring stack API endpoint URL
        timeout: HTTP request timeout in seconds
        max_retries: Maximum number of retry attempts
        retry_backoff: Backoff multiplier for exponential backoff
        session: aiohttp session with connection pooling
    """
    
    def __init__(
        self,
        endpoint: str,
        auth: Optional[Tuple[str, str]] = None,
        timeout: int = 3,
        max_retries: int = 3,
        retry_backoff: float = 1.0,
    ):
        """Initialize async HTTP transport.
        
        Args:
            endpoint: Monitoring stack base URL (e.g., 'http://vmagent:8429')
            auth: Optional tuple of (username, password) for HTTP basic auth
            timeout: Request timeout in seconds
            max_retries: Maximum retry attempts on failure
            retry_backoff: Backoff multiplier (1.0 = 1s, 2s, 4s, 8s...)
        """
        self.endpoint = endpoint.rstrip("/") + "/api/v1/import/prometheus"
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_backoff = retry_backoff
        
        # Setup auth
        self._auth = None
        if auth:
            self._auth = aiohttp.BasicAuth(auth[0], auth[1])
        
        # Session will be created lazily
        self._session: Optional[aiohttp.ClientSession] = None
        
        logger.debug(f"AsyncMetricsTransport initialized: endpoint={self.endpoint}")
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session lazily."""
        if self._session is None or self._session.closed:
            # Configure connection pooling and timeout
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            connector = aiohttp.TCPConnector(
                limit=20,  # Max connections
                limit_per_host=10,
            )
            
            self._session = aiohttp.ClientSession(
                auth=self._auth,
                timeout=timeout,
                connector=connector,
            )
        
        return self._session
    
    async def send(
        self,
        payload: str,
        max_retries: Optional[int] = None,
        retry_backoff: Optional[float] = None,
    ) -> None:
        """Send metrics payload to Monitoring stack asynchronously.
        
        Implements exponential backoff retry logic:
        - 1st retry: wait retry_backoff seconds
        - 2nd retry: wait retry_backoff * 2 seconds
        - 3rd retry: wait retry_backoff * 4 seconds
        - etc.
        
        Args:
            payload: Prometheus exposition format metrics
            max_retries: Override default max_retries for this request
            retry_backoff: Override default retry_backoff for this request
        
        Raises:
            TransportError: If all retry attempts fail
        """
        retries = max_retries if max_retries is not None else self.max_retries
        backoff = retry_backoff if retry_backoff is not None else self.retry_backoff
        
        session = await self._get_session()
        last_error = None
        
        for attempt in range(retries + 1):
            try:
                async with session.post(
                    self.endpoint,
                    data=payload.encode("utf-8"),
                    headers={"Content-Type": "text/plain"},
                ) as response:
                    response.raise_for_status()
                
                logger.debug(f"Successfully sent {len(payload)} bytes to Monitoring stack")
                return  # Success!
                
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                last_error = e
                
                if attempt < retries:
                    # Calculate exponential backoff: backoff * (2 ** attempt)
                    sleep_time = backoff * (2 ** attempt)
                    
                    logger.warning(
                        f"Metrics send failed (attempt {attempt + 1}/{retries + 1}): {e}. "
                        f"Retrying in {sleep_time:.1f}s..."
                    )
                    await asyncio.sleep(sleep_time)
                else:
                    logger.error(
                        f"Metrics send failed after {retries + 1} attempts: {e}"
                    )
        
        # All retries exhausted - raise error
        raise TransportError(
            f"Failed to send metrics after {retries + 1} attempts: {last_error}"
        )
    
    async def close(self) -> None:
        """Close the session and cleanup resources."""
        if self._session and not self._session.closed:
            await self._session.close()
            logger.debug("AsyncMetricsTransport closed")
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self._get_session()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - ensures cleanup."""
        await self.close()
