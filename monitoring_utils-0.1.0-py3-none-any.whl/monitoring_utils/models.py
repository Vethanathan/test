"""Data models for metrics."""

from dataclasses import dataclass
from typing import Dict, Optional
from enum import Enum
import asyncio


class MetricType(Enum):
    """Metric type enumeration."""
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    SUMMARY = "summary"


@dataclass
class Metric:
    """Represents a single metric data point.
    
    Attributes:
        name: Metric name (e.g., 'http_requests_total')
        value: Metric value (float)
        labels: Dictionary of label key-value pairs
        timestamp: Unix timestamp in seconds
        metric_type: Optional metric type (counter, gauge, histogram, summary)
        max_retries: Optional override for max retry attempts
        retry_backoff: Optional override for retry backoff multiplier
    """
    
    name: str
    value: float
    labels: Dict[str, str]
    timestamp: int
    metric_type: Optional[str] = None
    max_retries: Optional[int] = None
    retry_backoff: Optional[float] = None
    
    def to_prometheus(self) -> str:
        """Convert metric to Prometheus exposition format.
        
        Returns:
            String in format: metric_name{label1="value1"} value timestamp
        
        """
        if self.labels:
            # Sort labels for consistency
            labels_str = ",".join(
                f'{k}="{v}"' for k, v in sorted(self.labels.items())
            )
            return f"{self.name}{{{labels_str}}} {self.value} {self.timestamp}"
        return f"{self.name} {self.value} {self.timestamp}"
    
    def __str__(self) -> str:
        """String representation of metric."""
        return self.to_prometheus()


@dataclass
class CounterState:
    """Tracks counter state per metric name+labels combination."""
    current_value: float = 0.0
    
    def increment(self, delta: float) -> float:
        """Increment counter and return new value."""
        self.current_value += delta
        return self.current_value
    
    def get_value(self) -> float:
        """Get current counter value."""
        return self.current_value


class AsyncCounterRegistry:
    """Async-safe registry to track counter state across the application."""
    
    _instance = None
    _lock = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._counters: Dict[str, CounterState] = {}
            cls._lock = asyncio.Lock()
        return cls._instance
    
    def _make_key(self, name: str, labels: Optional[Dict[str, str]]) -> str:
        """Create unique key for counter."""
        labels_str = ""
        if labels:
            labels_str = ",".join(f"{k}={v}" for k, v in sorted(labels.items()))
        return f"{name}:{labels_str}"
    
    async def increment(self, name: str, delta: float, labels: Optional[Dict[str, str]] = None) -> float:
        """Increment counter and return new value (async-safe)."""
        key = self._make_key(name, labels)
        async with self._lock:
            if key not in self._counters:
                self._counters[key] = CounterState()
            return self._counters[key].increment(delta)
    
    async def get(self, name: str, labels: Optional[Dict[str, str]] = None) -> float:
        """Get current counter value."""
        key = self._make_key(name, labels)
        async with self._lock:
            if key in self._counters:
                return self._counters[key].get_value()
            return 0.0
    
    async def reset(self) -> None:
        """Reset all counters (for testing)."""
        async with self._lock:
            self._counters.clear()


class SyncCounterRegistry:
    """Thread-safe registry to track counter state across the application."""
    
    _instance = None
    _lock = None
    
    def __new__(cls):
        if cls._instance is None:
            import threading
            cls._instance = super().__new__(cls)
            cls._instance._counters: Dict[str, CounterState] = {}
            cls._lock = threading.Lock()
        return cls._instance
    
    def _make_key(self, name: str, labels: Optional[Dict[str, str]]) -> str:
        """Create unique key for counter."""
        labels_str = ""
        if labels:
            labels_str = ",".join(f"{k}={v}" for k, v in sorted(labels.items()))
        return f"{name}:{labels_str}"
    
    def increment(self, name: str, delta: float, labels: Optional[Dict[str, str]] = None) -> float:
        """Increment counter and return new value (thread-safe)."""
        key = self._make_key(name, labels)
        with self._lock:
            if key not in self._counters:
                self._counters[key] = CounterState()
            return self._counters[key].increment(delta)
    
    def get(self, name: str, labels: Optional[Dict[str, str]] = None) -> float:
        """Get current counter value."""
        key = self._make_key(name, labels)
        with self._lock:
            if key in self._counters:
                return self._counters[key].get_value()
            return 0.0
    
    def reset(self) -> None:
        """Reset all counters (for testing)."""
        with self._lock:
            self._counters.clear()
