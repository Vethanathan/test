"""HTTP transport layer for sending metrics to Monitoring stack."""

import time
import logging
from typing import Optional, Tuple

import requests
from requests.adapters import HTTPAdapter

from .exceptions import TransportError

logger = logging.getLogger(__name__)


class MetricsTransport:
    """HTTP transport for Monitoring stack.
    
    Handles:
    - Connection pooling
    - Automatic retries with exponential backoff
    - Request timeouts
    - HTTP basic authentication
    
    Attributes:
        endpoint: Full Monitoring stack API endpoint URL
        timeout: HTTP request timeout in seconds
        max_retries: Maximum number of retry attempts
        retry_backoff: Backoff multiplier for exponential backoff
        session: Requests session with connection pooling
    """
    
    def __init__(
        self,
        endpoint: str,
        auth: Optional[Tuple[str, str]] = None,
        timeout: int = 3,
        max_retries: int = 3,
        retry_backoff: float = 1.0,
    ):
        """Initialize HTTP transport.
        
        Args:
            endpoint: Monitoring stack base URL (e.g., 'http://vmagent:8429')
            auth: Optional tuple of (username, password) for HTTP basic auth
            timeout: Request timeout in seconds
            max_retries: Maximum retry attempts on failure
            retry_backoff: Backoff multiplier (1.0 = 1s, 2s, 4s, 8s...)
        """
        self.endpoint = endpoint.rstrip("/") + "/api/v1/import/prometheus"
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_backoff = retry_backoff
        
        # Setup session with connection pooling
        self.session = requests.Session()
        
        if auth:
            self.session.auth = auth
        
        # Configure HTTP adapter with connection pooling
        adapter = HTTPAdapter(
            pool_connections=10,
            pool_maxsize=20,
        )
        
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        logger.debug(f"MetricsTransport initialized: endpoint={self.endpoint}")
    
    def send(
        self,
        payload: str,
        max_retries: Optional[int] = None,
        retry_backoff: Optional[float] = None,
    ) -> None:
        """Send metrics payload to Monitoring stack.
        
        Implements exponential backoff retry logic:
        - 1st retry: wait retry_backoff seconds
        - 2nd retry: wait retry_backoff * 2 seconds
        - 3rd retry: wait retry_backoff * 4 seconds
        - etc.
        
        Args:
            payload: Prometheus exposition format metrics
            max_retries: Override default max_retries for this request
            retry_backoff: Override default retry_backoff for this request
        
        Raises:
            TransportError: If all retry attempts fail
        """
        retries = max_retries if max_retries is not None else self.max_retries
        backoff = retry_backoff if retry_backoff is not None else self.retry_backoff
        
        last_error = None
        
        for attempt in range(retries + 1):
            try:
                response = self.session.post(
                    self.endpoint,
                    data=payload.encode("utf-8"),
                    headers={"Content-Type": "text/plain"},
                    timeout=self.timeout,
                )
                response.raise_for_status()
                
                logger.debug(f"Successfully sent {len(payload)} bytes to Monitoring stack")
                return 
                
            except requests.exceptions.RequestException as e:
                last_error = e
                
                if attempt < retries:
                    # Calculate exponential backoff: backoff * (2 ** attempt)
                    sleep_time = backoff * (2 ** attempt)
                    
                    logger.warning(
                        f"Metrics send failed (attempt {attempt + 1}/{retries + 1}): {e}. "
                        f"Retrying in {sleep_time:.1f}s..."
                    )
                    time.sleep(sleep_time)
                else:
                    logger.error(
                        f"Metrics send failed after {retries + 1} attempts: {e}"
                    )
        
        # All retries exhausted - raise error
        raise TransportError(
            f"Failed to send metrics after {retries + 1} attempts: {last_error}"
        )
    
    def close(self) -> None:
        """Close the session and cleanup resources."""
        self.session.close()
        logger.debug("MetricsTransport closed")
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - ensures cleanup."""
        self.close()
